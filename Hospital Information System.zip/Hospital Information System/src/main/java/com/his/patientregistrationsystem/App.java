package com.his.patientregistrationsystem;

import java.util.List;

import javax.swing.UIManager;

import com.patientregistration.his.controller.PatientRegistrationController;
import com.patientregistration.his.model.JsonHandler;
import com.patientregistration.his.model.Patient;
import com.patientregistration.his.view.PatientRegistrationView;
import com.patientregistration.his.view.PatientTableView;

public class App {
	static PatientRegistrationController registrationController=null;
	public static void main(String[] args) {

		try {
			for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (Exception e) {
			System.err.println("Nimbus Look and Feel not applied. Falling back to default.");
		}

		PatientRegistrationView view = new  PatientRegistrationView();

		registrationController = new PatientRegistrationController(view);
	}

}


