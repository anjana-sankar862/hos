package com.consultation.his.gui;


public interface ClearActionListener {
	
	public void clearActionPerformed();


}
