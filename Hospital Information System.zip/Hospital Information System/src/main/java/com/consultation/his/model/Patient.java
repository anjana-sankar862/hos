
package com.consultation.his.model;

import java.time.LocalDate;
import java.util.Objects;

import com.appointment.his.model.Status;

public class Patient {
	private static int tokenCounter;
	private int mrdID;
	private String firstName;
	private String lastName;
	private LocalDate dob;
	private int ageYears;
	private int ageMonths;
	private String sex;
	private String maritalStatus;
	private String bloodGroup;
	private String email;
	private long phoneNumber;
	private String address;
	private String pincode;
	private String state;
	private String emergencyContactName;
	private long emergencyContactNumber;

	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Patient( String firstName, String lastName,LocalDate dob, int ageYears,int ageMonths,String sex, String maritalStatus,
			String bloodGroup, String email, long phoneNumber, String address, String pincode, String state,String emergencyContactName,
			long emergencyContactNumber) {
		tokenCounter = tokenCounter +1;
		this.mrdID = tokenCounter;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dob = dob;
		this.ageYears=ageYears;
		this.ageMonths=ageMonths;
		this.sex = sex;
		this.maritalStatus = maritalStatus;
		this.bloodGroup = bloodGroup;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.address = address;
		this.pincode = pincode;
		this.state = state;
		this.emergencyContactName=emergencyContactName;
		this.emergencyContactNumber=emergencyContactNumber;
	}
	// Getters and setters
	public int getMrdID() {
		return mrdID;
	}
	public void setMrdID(int mrdID) {
		this.mrdID = mrdID;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public int getAgeYears() {
		return ageYears;
	}
	public void setAgeYears(int ageYears) {
		this.ageYears = ageYears;
	}
	public int getAgeMonths() {
		return ageMonths;
	}
	public void setAgeMonths(int ageMonths) {
		this.ageMonths = ageMonths;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public static int getTokenCounter() {
		return tokenCounter;
	}
	public static void setTokenCounter(int tokenCounter) {
		Patient.tokenCounter = tokenCounter;
	}
	public String getEmergencyContactName() {
		return emergencyContactName;
	}
	public void setEmergencyContactName(String emergencyContactName) {
		this.emergencyContactName = emergencyContactName;
	}
	public long getEmergencyContactNumber() {
		return emergencyContactNumber;
	}
	public void setEmergencyContactNumber(long emergencyContactNumber) {
		this.emergencyContactNumber = emergencyContactNumber;
	}
	@Override
	public String toString() {
		return firstName + " " + lastName;
	}
	@Override
	public int hashCode() {
		return Objects.hash(address, ageMonths, ageYears, bloodGroup, dob, email, emergencyContactName,
				emergencyContactNumber, firstName, lastName, maritalStatus, mrdID, phoneNumber, pincode, sex, state);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Patient other = (Patient) obj;
		return Objects.equals(address, other.address) && ageMonths == other.ageMonths && ageYears == other.ageYears
				&& Objects.equals(bloodGroup, other.bloodGroup) && Objects.equals(dob, other.dob)
				&& Objects.equals(email, other.email)
				&& Objects.equals(emergencyContactName, other.emergencyContactName)
				&& emergencyContactNumber == other.emergencyContactNumber && Objects.equals(firstName, other.firstName)
				&& Objects.equals(lastName, other.lastName) && Objects.equals(maritalStatus, other.maritalStatus)
				&& mrdID == other.mrdID && phoneNumber == other.phoneNumber && Objects.equals(pincode, other.pincode)
				&& Objects.equals(sex, other.sex) && Objects.equals(state, other.state);
	}




}
