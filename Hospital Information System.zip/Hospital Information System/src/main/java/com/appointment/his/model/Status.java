package com.appointment.his.model;

public enum Status {
ACTIVE,CANCELED,COMPLETED;
}
